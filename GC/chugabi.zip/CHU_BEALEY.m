%--------------------------------------------------------------------------
% ALGORITMO GENÉTICO CHU-BEALEY (MESTRE) - VERSÃO FINAL E CORRIGIDA
%--------------------------------------------------------------------------
%% 0. INICIALIZAÇÃO E CONFIGURAÇÃO
clc;
clear;
close all;

% --- Parâmetros do Algoritmo ---
tam_pop           = 50;    % Tamanho da população
num_iteracoes     = 100;    % Critério de parada: número de indivíduos a serem criados
taxa_cross        = 0.8;    % Probabilidade de crossover (alta)
taxa_mut          = 0.05;    % Probabilidade de um descendente sofrer mutação (relativamente alta)
tam_torneio       = 3;      % Número de indivíduos na seleção por torneio
S_base            = 100;    % Potência base (MVA)
penal_corte       = 10e3;   % Penalidade por corte de carga

%% 1. CARREGAMENTO DOS DADOS DO SISTEMA
fprintf('Carregando dados do sistema...\n');
% DADOS DAS BARRAS
barras = [1 0 240 0; 2 0 165 486.66; 3 0 0 587.08; 4 0 0 0; 5 0 40 351.42; 6 0 34 0; 7 0 136 448.03; 8 0 230 505.87; 9 0 0 519.69; 10 0 0 88.84; 11 0 108 220.15; 12 0 47 0; 13 0 0 260.08; 14 0 0 0; 15 0 0 562.84; 16 0 0 351.9; 17 0 35 203; 18 0 540 54.1; 19 0 1340 29.28; 20 0 45 302.27; 21 0 0 277.44; 22 0 200 79.17; 23 0 0 302.27; 24 0 150 0; 25 0 86 0; 26 0 70 0; 27 0 0 396.71; 28 0 14 486.39; 29 0 618 505.96; 30 0 0 199.55; 31 0 189 391.88; 32 0 0 188.33; 33 0 0 247.24; 34 0 0 115.81; 35 0 200 256.86; 36 0 44 167.29; 37 0 138 176.3; 38 0 15 129.72; 39 0 15 268.19; 40 0 305 0; 41 0 100 81.85; 42 0 0 152.39; 43 0 0 52.9; 44 0 23 384.64; 45 0 1208 0; 46 0 150 181.62; 47 0 0 61.6; 48 0 885 896.26; 49 0 0 193.27; 50 0 240 632.75; 51 0 0 190.45; 52 0 0 55.6; 53 0 320 0; 54 0 0 114.19; 55 0 40 333.59; 56 0 0 0; 57 0 130 336.94; 58 0 190 0; 59 0 160 0; 60 3 1216 0; 61 0 155 0; 62 0 0 0; 63 0 1090 52.77; 64 0 280 132.35; 65 0 0 197.58; 66 0 300 0; 67 0 474 397.98; 68 0 0 0; 69 0 0 106.61; 70 0 180 0; 71 0 424 471.21; 72 0 0 0; 73 0 0 0; 74 0 0 0; 75 0 0 0; 76 0 40 0; 77 0 0 82.85; 78 0 0 54.07; 79 0 300 146.87; 80 0 0 88.34; 81 0 0 0; 82 0 0 0; 83 0 0 0; 84 0 500 0; 85 0 0 0; 86 0 850 0; 87 0 0 0; 88 0 300 0; 89 0 0 0; 90 0 0 0; 91 0 0 0; 92 0 0 0; 93 0 0 0];
% DADOS DOS RAMOS
ramos = [52 88 0 0 0.098 300 34190 5; 43 88 0 0 0.1816 250 39560 5; 57 81 0 0 0.0219 550 58890 5; 73 82 0 0 0.0374 550 97960 5; 27 89 0 0 0.0267 450 13270 5; 74 89 0 0 0.0034 550 14570 5; 73 89 0 0 0.0246 550 66650 5; 79 83 0 0 0.0457 350 15400 5; 8 67 0 0 0.224 250 29200 5; 39 86 0 0 0.0545 350 9880 5; 25 28 1 0 0.0565 320 9767 5; 25 29 1 0 0.057 320 9882 5; 13 14 2 0 0.0009 350 3902 5; 13 20 1 0 0.0178 350 5742 5; 13 23 1 0 0.0277 350 7007 5; 14 31 2 0 0.1307 250 18622 5; 14 18 2 0 0.1494 250 20232 5; 14 60 2 0 0.1067 300 15977 5; 2 4 2 0 0.0271 350 6662 5; 2 9 1 0 0.0122 350 5282 5; 2 83 1 0 0.02 570 5972 5; 9 83 1 0 0.02 400 5972 5; 15 18 1 0 0.0365 450 7927 5; 15 17 1 0 0.0483 320 9422 5; 15 20 1 0 0.0513 320 9652 5; 15 76 1 0 0.0414 320 9882 5; 15 24 1 0 0.0145 350 5282 5; 37 61 1 0 0.0139 350 4937 5; 19 61 2 0 0.1105 250 16092 5; 61 68 1 0 0.0789 250 12412 5; 37 68 1 0 0.0544 320 9652 5; 40 68 1 0 0.132 320 18162 5; 12 75 1 0 0.0641 320 11492 5; 24 75 1 0 0.0161 350 5512 5; 35 36 1 0 0.2074 250 27362 5; 27 35 1 0 0.1498 250 22072 5; 35 44 2 0 0.1358 250 20347 5; 38 68 1 0 0.0389 350 7927 5; 38 39 1 0 0.03 350 6317 5; 27 80 1 0 0.0242 350 7007 5; 44 80 1 0 0.1014 250 17587 5; 56 81 1 0 0.0114 550 32858 5; 45 54 1 0 0.0946 320 13562 5; 45 50 2 0 0.007 350 4362 5; 10 78 1 0 0.0102 350 4937 5; 7 78 1 0 0.0043 350 4132 5; 30 64 1 0 0.1533 250 20577 5; 30 65 1 0 0.091 250 13677 5; 30 72 2 0 0.0173 350 5512 5; 55 57 1 0 0.0174 600 46808 5; 57 84 1 0 0.0087 600 26658 5; 55 84 1 0 0.0087 600 26658 5; 56 57 2 0 0.024 600 62618 5; 9 77 1 0 0.019 350 5857 5; 77 79 1 0 0.0097 350 5167 5; 1 59 2 0 0.0232 350 6202 5; 59 67 2 0 0.118 250 16667 5; 8 59 2 0 0.1056 250 15402 5; 1 3 1 0 0.104 250 15862 5; 3 71 1 0 0.0136 450 5167 5; 3 6 1 0 0.0497 350 9422 5; 55 62 1 0 0.0281 550 70988 5; 47 52 1 0 0.0644 350 10572 5; 51 52 1 0 0.0859 250 12872 5; 29 31 2 0 0.1042 250 32981 5; 41 42 1 0 0.0094 350 4707 5; 40 42 1 0 0.0153 350 5167 5; 46 53 2 0 0.1041 250 14597 5; 46 51 1 0 0.1141 250 16322 5; 69 70 2 0 0.0228 350 6202 5; 66 69 2 0 0.1217 250 17127 5; 9 69 2 0 0.1098 350 15747 5; 60 69 2 0 0.0906 350 13677 5; 31 32 1 0 0.0259 350 6547 5; 32 34 1 0 0.054 350 9767 5; 16 18 1 0 0.0625 350 10917 5; 16 23 1 0 0.0238 350 6892 5; 16 21 1 0 0.0282 350 6892 5; 31 34 1 0 0.0792 250 12412 5; 31 33 2 0 0.0248 350 6432 5; 31 60 2 0 0.1944 250 25982 5; 31 72 2 0 0.0244 350 6317 5; 47 54 2 0 0.1003 250 14252 5; 47 49 2 0 0.0942 250 13562 5; 18 58 2 0 0.0212 350 5742 5; 18 20 1 0 0.0504 350 9537 5; 18 66 2 0 0.0664 350 11377 5; 18 21 1 0 0.0348 350 7467 5; 18 22 1 0 0.0209 350 6432 5; 19 22 1 0 0.0691 350 11722 5; 4 5 3 0 0.0049 350 4247 5; 5 6 2 0 0.0074 350 4477 5; 17 23 1 0 0.0913 250 12987 5; 17 76 1 0 0.002 350 3902 5; 12 17 1 0 0.0086 350 4707 5; 1 71 2 0 0.0841 250 14367 5; 1 8 1 0 0.081 250 13217 5; 1 11 1 0 0.0799 250 12527 5; 4 36 2 0 0.085 250 13562 5; 19 58 1 0 0.0826 320 11722 5; 27 64 1 0 0.028 350 6777 5; 27 28 1 0 0.0238 350 6202 5; 27 44 1 0 0.0893 250 16322 5; 26 27 1 0 0.0657 350 10917 5; 27 29 1 0 0.0166 350 5052 5; 19 66 1 0 0.0516 350 9307 5; 73 74 1 0 0.0214 600 58278 5; 64 65 1 0 0.0741 350 11837 5; 29 64 1 0 0.0063 350 4362 5; 4 34 2 0 0.1016 270 14942 5; 34 70 2 0 0.0415 350 8272 5; 33 34 1 0 0.1139 320 16322 5; 8 71 1 0 0.0075 400 4477 5; 54 63 3 0 0.0495 320 9077 5; 48 63 1 0 0.0238 350 6317 5; 67 68 2 0 0.166 250 22072 5; 39 68 1 0 0.0145 350 5282 5; 8 9 1 0 0.0168 350 5972 5; 79 87 1 0 0.0071 350 4477 5; 8 87 1 0 0.0132 350 5167 5; 39 43 1 0 0.1163 250 16552 5; 41 43 1 0 0.1142 250 16322 5; 23 24 1 0 0.0255 350 6317 5; 21 22 1 0 0.0549 350 9882 5; 26 28 1 0 0.0512 350 9307 5; 28 29 1 0 0.0281 350 6777 5; 6 10 1 0 0.0337 350 7582 5; 33 72 1 0 0.0228 350 6202 5; 39 40 2 0 0.102 250 16207 5; 12 76 1 0 0.0081 350 4707 5; 48 54 3 0 0.0396 350 8042 5; 50 54 2 0 0.0876 250 12872 5; 62 73 1 0 0.0272 750 73158 5; 49 53 2 0 0.1008 250 14252 5; 40 41 1 0 0.0186 350 5742 5; 45 81 1 0 0.0267 450 13270 5; 64 74 1 0 0.0267 500 13270 5; 54 56 3 0 0.0267 450 13270 5; 60 62 3 0 0.0257 450 13270 5; 72 73 2 0 0.0267 500 13270 5; 19 82 1 0 0.0267 450 13270 5; 55 82 1 0 0.029 550 77498 5; 62 82 1 0 0.0101 600 30998 5; 83 85 2 0 0.0267 450 13270 5; 82 85 1 0 0.0341 700 89898 5; 19 86 1 0 0.1513 300 20922 5; 68 86 1 0 0.0404 350 8272 5; 7 90 2 0 0.005 350 4247 5; 3 90 1 0 0.0074 350 4592 5; 90 91 1 0 0.0267 550 13270 5; 85 91 1 0 0.0139 600 40298 5; 11 92 1 0 0.0267 450 13270 5; 1 93 1 0 0.0267 450 13270 5; 92 93 1 0 0.0097 600 30068 5; 91 92 1 0 0.0088 600 27588 5];

% --- Extração de Parâmetros Iniciais ---
ni = ramos(:,1);                                                        
nj = ramos(:,2);                                                        
n_ram = size(ramos, 1);                                                 
S_base = 100;                                                           
penal_corte = 10e3;                                                     
n_total_max = ramos(:, 8); 
n_ini = ramos(:, 3); 
n_max_add = n_total_max - n_ini; 
% --- Variáveis para guardar o melhor resultado durante a evolução ---
melhor_solucao_global = zeros(n_ram, 1); 
melhor_custo_global = inf;                                              
% historico_custo = zeros(n_ger, 1);                                      

%% 1. GERAR A POPULAÇÃO INICIAL
fprintf('Gerando a população inicial...\n');                            
pop = zeros(tam_pop, n_ram); 
 % for j = 1:n_ram 
 %     pop(:, j) = randi([0, n_max_add(j)], tam_pop, 1);
 % end
% solucao_semente = cria_solucao_inicial(barras, ramos, S_base, penal_corte);
% pop(1, :) = solucao_semente;
% fprintf('Solução inteligente injetada na população inicial.\n');

%% 2. AVALIAÇÃO DA POPULAÇÃO INICIAL
fprintf('Avaliando a população inicial...\n');
custo_pop = zeros(tam_pop, 1);
anfitness_pop = zeros(tam_pop, 1);
for i = 1:tam_pop
    [custo_total, corte_pu] = funcao_fitness_DC(pop(i, :), barras, ramos, S_base, penal_corte);
    custo_pop(i) = custo_total - (corte_pu * penal_corte);
    anfitness_pop(i) = corte_pu;
end

%% INÍCIO DO LOOP DAS GERAÇÕES (ITERAÇÕES)
for iteracao = 1:num_iteracoes
    fprintf('Iteração %d de %d...\n', iteracao, num_iteracoes);
    
    %% 3. SELEÇÃO (POR TORNEIO)
    idx_competidores = randi(tam_pop, tam_torneio, 1);
    [~, idx_vencedor_local] = min(custo_pop(idx_competidores));
    idx_pai1 = idx_competidores(idx_vencedor_local);
    idx_competidores = randi(tam_pop, tam_torneio, 1);
    [~, idx_vencedor_local] = min(custo_pop(idx_competidores));
    idx_pai2 = idx_competidores(idx_vencedor_local);
    pai1 = pop(idx_pai1, :);
    pai2 = pop(idx_pai2, :);

    %% 4. RECOMBINAÇÃO (CROSSOVER)
    filho1 = pai1;
    filho2 = pai2;
    if rand() < taxa_cross
        ponto_corte = randi(n_ram - 1);
        filho1 = [pai1(1:ponto_corte), pai2(ponto_corte+1:end)];
        filho2 = [pai2(1:ponto_corte), pai1(ponto_corte+1:end)];
    end
    
    custo_filho1 = funcao_fitness_DC(filho1, barras, ramos, S_base, penal_corte);
    custo_filho2 = funcao_fitness_DC(filho2, barras, ramos, S_base, penal_corte);
    if custo_filho1 <= custo_filho2
        descendente = filho1;
    else
        descendente = filho2;
    end
    
    %% 5. MUTAÇÃO
    if rand() < taxa_mut
        for j = 1:n_ram
            if rand() < taxa_mut
                descendente(j) = randi([0, n_max_add(j)]);
            end
        end
    end
    
    %% 6. MELHORAMENTO LOCAL (PODA)
    descendente_melhorado = funcao_poda(descendente, barras, ramos, S_base, penal_corte);
    
    [custo_desc, anfitness_desc] = funcao_fitness_DC(descendente_melhorado, barras, ramos, S_base, penal_corte);
    fitness_desc = custo_desc - (anfitness_desc * penal_corte);
    
    %% 7. CRITÉRIO DE ACEITAÇÃO E ATUALIZAÇÃO DA POPULAÇÃO
    [pior_anfitness, idx_pior_anfitness] = max(anfitness_pop);
    aceito = false;
    
    if anfitness_desc > 1e-6
        if anfitness_desc < pior_anfitness
            pop(idx_pior_anfitness, :) = descendente_melhorado;
            custo_pop(idx_pior_anfitness) = fitness_desc;
            anfitness_pop(idx_pior_anfitness) = anfitness_desc;
            aceito = true;
        end
    else 
        idx_viaveis = find(anfitness_pop < 1e-6);
        if isempty(idx_viaveis)
             pop(idx_pior_anfitness, :) = descendente_melhorado;
             custo_pop(idx_pior_anfitness) = fitness_desc;
             anfitness_pop(idx_pior_anfitness) = anfitness_desc;
             aceito = true;
        else
            [pior_fitness_viavel, idx_local] = max(custo_pop(idx_viaveis));
            idx_pior_viavel = idx_viaveis(idx_local);
            
            if fitness_desc < pior_fitness_viavel
                pop(idx_pior_viavel, :) = descendente_melhorado;
                custo_pop(idx_pior_viavel) = fitness_desc;
                anfitness_pop(idx_pior_viavel) = anfitness_desc;
                aceito = true;
            end
        end
    end

    if aceito && anfitness_desc < 1e-6 && fitness_desc < melhor_custo_global
        melhor_custo_global = fitness_desc;
        melhor_solucao_global = descendente_melhorado;
        fprintf('  -> Novo melhor custo global encontrado: %.2f\n', melhor_custo_global);
    end
    
    custos_viaveis = custo_pop(anfitness_pop < 1e-6);
    if ~isempty(custos_viaveis)
        historico_custo(iteracao) = min(custos_viaveis);
    elseif melhor_custo_global ~= inf
        historico_custo(iteracao) = melhor_custo_global;
    else
        historico_custo(iteracao) = min(custo_pop);
    end
end

%% RESULTADOS FINAIS
fprintf('\n\nOtimização Genética Concluída!\n');
fprintf('====================================================\n');
fprintf('Melhor Custo Total Encontrado: %.2f\n', melhor_custo_global);
fprintf('Melhor Plano de Expansão:\n');

if isrow(melhor_solucao_global)
    melhor_solucao_global = melhor_solucao_global';
end
tabela_final = table(ni, nj, melhor_solucao_global, 'VariableNames', {'De', 'Para', 'Circuitos_Adicionados'});
disp(tabela_final);

figure('Name', 'Convergência do Algoritmo Genético');
plot(1:num_iteracoes, historico_custo, 'LineWidth', 2);
title('Evolução do Melhor Custo Viável por Geração');
xlabel('Iteração');
ylabel('Custo de Investimento');
grid on;